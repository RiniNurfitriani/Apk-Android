package com.example.rekreasi;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
//import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivity extends Activity implements OnClickListener{

    private Button bRekreasi;
    private Button bAbout;
    private Button bQuit;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		bRekreasi = (Button) findViewById(R.id.button1);
		bRekreasi.setOnClickListener(this);
        bAbout = (Button) findViewById(R.id.button2);
        bAbout.setOnClickListener(this);
        bQuit = (Button) findViewById(R.id.button3);
        bQuit.setOnClickListener(this);
        
  }
  @Override
  public void onClick(View v) {
      // TODO Auto-generated method stub
      switch(v.getId())
      {
          case R.id.button1 :
              Intent i = new Intent(this,Rekreasi.class);
              startActivity(i);
              break;
          case R.id.button2 :
              Intent i2 = new Intent(this, About.class);
              startActivity(i2);
        	  break;
          case R.id.button3 :
              close(); //perintah keluar aplikasi sambung kebawah
              
      }
  }
  private void close() {
  	// TODO Auto-generated method stub
  	AlertDialog.Builder builder = new AlertDialog.Builder(this);
     	builder.setMessage("Apakah Anda Benar-Benar ingin keluar?").setCancelable(false)
    	.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
    		public void onClick(DialogInterface dialog, int id) {
    			finish();
    		}
    	})
     	.setNegativeButton("Tidak",new DialogInterface.OnClickListener() {
       	public void onClick(DialogInterface dialog, int id) {
          	dialog.cancel();
        	}
     	})
    	.show();
	}
}