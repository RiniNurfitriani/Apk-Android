package com.example.rekreasi;

import android.app.Activity;
import android.os.Bundle;

public class Tangkubanperahu extends Activity {
	@Override
	protected void onCreate(Bundle savedInstateState) {		
		Bundle savedInstanceState = null;
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState );
		setContentView(R.layout.tangkubanperahu);
		
		
	}
	}