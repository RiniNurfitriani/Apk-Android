package com.example.rekreasi;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
//import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
//import android.widget.Toast;

public class Rekreasi extends Activity implements OnClickListener{

    private Button bTangkubanperahu;
    private Button bSitupatenggang;
    private Button bDeranch;
    private Button bKawahputih;
    private Button bKampunggajah;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.rekreasi);
		bTangkubanperahu = (Button) findViewById(R.id.button1);
		bTangkubanperahu.setOnClickListener(this);
		bSitupatenggang = (Button) findViewById(R.id.button2);
		bSitupatenggang.setOnClickListener(this);
		bDeranch = (Button) findViewById(R.id.button3);
		bDeranch.setOnClickListener(this);
		bKawahputih = (Button) findViewById(R.id.button4);
		bKawahputih.setOnClickListener(this);
		bKampunggajah = (Button) findViewById(R.id.button5);
		bKampunggajah.setOnClickListener(this);

  }
  @Override
  public void onClick(View v) {
      // TODO Auto-generated method stub
      switch(v.getId())
      {
          case R.id.button1 :
              Intent i = new Intent(this, Tangkubanperahu.class);
              startActivity(i);
              break;
          case R.id.button2 :
              Intent i2 = new Intent(this, Situpatenggang.class);
              startActivity(i2);
              break;
          case R.id.button3 :
              Intent i3 = new Intent(this, Deranch.class);
              startActivity(i3);
              break;
          case R.id.button4 :
              Intent i4 = new Intent(this, Kawahputih.class);
              startActivity(i4);
              break;
          case R.id.button5 :
              Intent i5 = new Intent(this, Kampunggajah.class);
              startActivity(i5);
              break;

      }
  }
}